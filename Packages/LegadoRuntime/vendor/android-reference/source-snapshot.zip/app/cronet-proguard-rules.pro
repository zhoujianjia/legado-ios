# -------- Config Path: components/cronet/android/cronet_impl_native_proguard.cfg --------
# Proguard config for apps that depend on cronet_impl_native_java.jar.

# This constructor is called using the reflection from Cronet API (cronet_api.jar).
-keep class org.chromium.net.impl.NativeCronetProvider {
    public <init>(android.content.Context);
}

# Used by reflection from NativeCronetProvider#isEnabled.
-keep class org.chromium.net.impl.NativeCronetProviderSentinel

# While Chrome doesn't need to keep these with their version of R8, some cronet
# users may be on other optimizers which still require the annotation to be
# kept in order for the keep rules to work.
-keep @interface internal.org.chromium.build.annotations.DoNotInline
-keep @interface internal.org.chromium.build.annotations.UsedByReflection
-keep @interface internal.org.chromium.build.annotations.IdentifierNameString
# ** prefixed since JNI Zero classes included in cronet are jarjared to prevent
# clashes with the real JNI Zero. See https://crbug.com/353534209
-keep @interface **org.jni_zero.AccessedByNative
-keep @interface **org.jni_zero.CalledByNative
-keep @interface **org.jni_zero.CalledByNativeUnchecked

# Suppress unnecessary warnings.
-dontnote org.chromium.net.ProxyChangeListener$ProxyReceiver
-dontnote org.chromium.net.AndroidKeyStore
# Needs 'boolean onSearchRequested(android.view.SearchEvent)' (API level 23).
-dontwarn org.chromium.base.WindowCallbackWrapper

# Generated for chrome apk and not included into cronet.
-dontwarn org.chromium.base.library_loader.LibraryLoader
-dontwarn org.chromium.base.SysUtils

# Objects of this type are passed around by native code, but the class
# is never used directly by native code. Since the class is not loaded, it does
# not need to be preserved as an entry point.
-dontnote org.chromium.net.UrlRequest$ResponseHeadersMap
# https://android.googlesource.com/platform/sdk/+/marshmallow-mr1-release/files/proguard-android.txt#54
-dontwarn android.support.**

# See crbug.com/1440987. We must keep every native that we are manually
# registering. If Cronet bumps its min-sdk past 21, we may be able to move to
# automatic JNI registration.
# ** prefixed since JNI Zero classes included in cronet are jarjared to prevent
# clashes with the real JNI Zero. See https://crbug.com/353534209
-keepclasseswithmembers,includedescriptorclasses,allowaccessmodification class org.chromium.**,**J.N {
  native <methods>;
}

# Part of the Android System SDK; false positive when pointing ProGuard to the
# public SDK.
-dontwarn android.os.SystemProperties

# These references are missing, but that's fine because they are dead code. See
# https://crbug.com/447361039.
# TODO(https://crbug.com/447361039): -dontwarn rules are dangeous, because if
# Cronet starts using these classes we will not be warned that they are missing.
# We should either ship these classes or refactor the code to stop referencing
# them.
-dontwarn internal.org.chromium.build.NativeLibraries
-dontwarn org.chromium.base.version_info.VersionConstantsBridgeJni

# Cronet 152 repackages protobuf under org.chromium.net.internal. Generated
# message fields are read by the protobuf schema runtime through reflection.
# Keep them from being removed or renamed by the app's release shrinker.
-keepclassmembers class * extends org.chromium.net.internal.com.google.protobuf.GeneratedMessageLite {
  <fields>;
}

# Part of the Android System SDK; false positive when R8 runs against the
# standard public SDK. Cronet's telemetry code references these classes on
# newer platform releases, while the app still supports older API levels.
-dontwarn android.util.StatsEvent
-dontwarn android.util.StatsEvent$*
-dontwarn android.util.StatsLog

# -------- Config Path: third_party/jni_zero/proguard.flags --------
# Copyright 2023 The Chromium Authors
# Use of this source code is governed by a BSD-style license that can be
# found in the LICENSE file.

# Keeps for method level annotations.
-keepclasseswithmembers,allowaccessmodification class ** {
  @**org.jni_zero.AccessedByNative <fields>;
}
-keepclasseswithmembers,includedescriptorclasses,allowaccessmodification,allowoptimization class ** {
  @**org.jni_zero.CalledByNative <methods>;
}
-keepclasseswithmembers,includedescriptorclasses,allowaccessmodification,allowoptimization class ** {
  @**org.jni_zero.CalledByNativeUnchecked <methods>;
}

# Allow unused native methods to be removed, but prevent renaming on those that
# are kept.
# TODO(crbug.com/315973491): Restrict the broad scope of this rule.
-keepclasseswithmembernames,includedescriptorclasses,allowaccessmodification class ** {
  native <methods>;
}

# Used when multiplexing. We don't package our own @UsedByReflection, so using this instead.
-keepclasseswithmembers class !cr_allowunused,**J.N {
  public long *_HASH;
}

# -------- Config Path: components/cronet/android/cronet_impl_platform_proguard.cfg --------
# -------- Config Path: components/cronet/android/cronet_impl_platform_proguard.cfg --------
# Proguard config for apps that depend on cronet_impl_platform_java.jar.

# This constructor is called using the reflection from Cronet API (cronet_api.jar).
-keep class org.chromium.net.impl.JavaCronetProvider {
    public <init>(android.content.Context);
}

# -------- Config Path: components/cronet/android/httpengine_native_provider_proguard.cfg --------
# -------- Config Path: components/cronet/android/httpengine_native_provider_proguard.cfg --------
# Proguard config for apps that depend on httpengine_native_provider_java.jar.

# This constructor is called using the reflection from Cronet API (cronet_api.jar).
-keep class org.chromium.net.impl.HttpEngineNativeProvider {
    public <init>(android.content.Context);
}

