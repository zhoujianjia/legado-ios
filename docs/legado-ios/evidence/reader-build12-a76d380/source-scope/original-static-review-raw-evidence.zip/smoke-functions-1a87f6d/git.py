def git(*args, binary=False):
    value = subprocess.check_output(["git", "-C", str(REPO), *args], text=not binary)
    return value if binary else value.strip()
