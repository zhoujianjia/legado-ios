def local_product_source_inputs(repo=None):
    """Check the selected, simple @Test declarations, not arbitrary Swift syntax.

    A declaration/argument-shape change fails closed for deliberate review. This
    is a source inventory; it is never a claim that Swift compiled or executed.
    """
    repo = REPO if repo is None else Path(repo)
    records, found = [], set()
    pattern = re.compile(r"^[ \t]*@Test(?:\(([^\r\n]*)\))?\s+(?:nonisolated\s+)?func (\w+)\(([^)]*)\)", re.MULTILINE)
    for suite, expected in LOCAL_PRODUCT_CASES.items():
        filenames = [suite + ".swift"]
        if suite == "UserFontSettingsTests":
            filenames.append("UserFontTransactionTests.swift")
        actual = set()
        for filename in filenames:
            relative = "Tests/iOS/yuedu appTests/" + filename
            path = repo / relative
            data = path.read_bytes()
            text = data.decode("utf-8-sig")
            if filename == "UserFontTransactionTests.swift":
                if "extension UserFontSettingsTests {" not in text or "@Suite(" in text:
                    raise ValueError("Font transactions must extend the same serialized UserFontSettingsTests suite")
            elif re.search(r"\b(?:struct|class)\s+" + re.escape(suite) + r"\b", text) is None:
                raise ValueError("Selected source suite declaration is missing: " + suite)
            if suite == "UserFontSettingsTests" and filename == suite + ".swift":
                if re.search(r"@Suite\([^\r\n]*\.serialized[^\r\n]*\)", text) is None:
                    raise ValueError("Font settings and transaction cases require one serialized suite")
            declarations = pattern.findall(text)
            if len(declarations) != len(re.findall(r"^[ \t]*@Test\b", text, re.MULTILINE)):
                raise ValueError("Unsupported or missing selected @Test declaration: " + relative)
            for attributes, name, parameters in declarations:
                labels = []
                for parameter in parameters.split(",") if parameters.strip() else []:
                    match = re.fullmatch(r"\s*(\w+)\s*:\s*[\w.]+\s*", parameter)
                    if match is None:
                        raise ValueError("Unsupported selected test signature: " + name)
                    labels.append(match[1] + ":")
                method = name + "(" + "".join(labels) + ")"
                identity = suite + "/" + method
                parameter_types = {"failedImportPreservesLibrary": "fault:FontFault,global:Bool",
                    "heldImportHasOnePublicationBoundary": "cancelFirst:Bool", "invalidNamesAreRejected": "name:String",
                    "missingOldFilesCanBeRepaired": "reimport:Bool"}
                if name in parameter_types and re.sub(r"\s+", "", parameters) != parameter_types[name]:
                    raise ValueError("Font transaction parameter types differ from the fixed source selection")
                if identity in found:
                    raise ValueError("Duplicate selected source method: " + identity)
                found.add(identity)
                actual.add(method)
                if "arguments:" in attributes:
                    arguments = attributes.split("arguments:", 1)[1].strip()
                    if name == "failedImportPreservesLibrary":
                        cases = re.search(r"\benum FontFault\b[^\{]*\{\s*case ([^\r\n}]+)", text)
                        faults = [] if cases is None else [part.strip() for part in cases[1].split(",")]
                        if (re.sub(r"\s+", "", arguments) != "FontFault.allCases,[false,true]"
                                or faults != ["copyCandidate", "metadata", "copyOriginal", "unregister", "register", "removeAfterMutation"]):
                            raise ValueError("Font import fault matrix differs from the fixed 6 x 2 selection")
                    elif name in ("heldImportHasOnePublicationBoundary", "missingOldFilesCanBeRepaired"):
                        values = json.loads(arguments)
                        if (not isinstance(values, list) or any(type(value) is not bool for value in values)
                                or values != [False, True]):
                            raise ValueError("Font cancellation arguments differ from the fixed selection")
                    elif name == "invalidNamesAreRejected":
                        if json.loads(arguments) != ["../outside.ttf", "/outside.ttf", "folder/font.ttf", "folder\\font.ttf", ".", ".."]:
                            raise ValueError("Unsafe font filename arguments differ from the fixed selection")
                    else:
                        raise ValueError("Unexpected parameterized local-product method: " + identity)
                elif LOCAL_PRODUCT_EXECUTIONS.get(identity, 1) != 1:
                    raise ValueError("Parameterized font method lost its arguments: " + identity)
            records.append({"path": relative, "sha256": hashlib.sha256(data).hexdigest(), "bytes": len(data)})
        if actual != set(expected):
            raise ValueError("Selected source method identities differ for " + suite)
    if (set(LOCAL_PRODUCT_EXECUTIONS) != found or len(found) != LOCAL_PRODUCT_METHOD_COUNT
            or sum(LOCAL_PRODUCT_EXECUTIONS.values()) != LOCAL_PRODUCT_EXECUTION_COUNT):
        raise ValueError("Local-product source method/execution inventory differs from 50/68")
    return {"methodCount": LOCAL_PRODUCT_METHOD_COUNT, "plannedExecutionCount": LOCAL_PRODUCT_EXECUTION_COUNT,
            "expectedExecutionsByMethod": dict(sorted(LOCAL_PRODUCT_EXECUTIONS.items())), "sourceInputs": records}
