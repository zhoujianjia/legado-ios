def main():
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="phase", required=True)
    validation = commands.add_parser("validate-tag")
    validation.add_argument("--tag-prefix", choices=("reader-smoke-", "reader-renewal-"), default="reader-smoke-")
    preparation = commands.add_parser("prepare")
    preparation.add_argument("--directory", type=Path, required=True)
    preparation.add_argument("--tag-prefix", choices=("reader-smoke-", "reader-renewal-"), default="reader-smoke-")
    verify = commands.add_parser("verify-summary")
    verify.add_argument("--summary", type=Path, required=True)
    verify.add_argument("--expected", type=int, required=True)
    verify.add_argument("--expected-executions", type=int)
    commands.add_parser("local-product-source", help="Inventory the fixed source selection without running Swift")
    product = commands.add_parser("verify-local-product", help="Require local-product 50 methods/68 executions and source method identities")
    product.add_argument("--summary", type=Path, required=True)
    product.add_argument("--tests", type=Path, required=True)
    summarize = commands.add_parser("result", help="Require configuration=9, product=50/68, paging=12 and TXT UI=1 summaries")
    for name in ("audit", "settings", "unit", "ui", "paging", "product", "product-tests", "output"):
        summarize.add_argument("--" + name, type=Path, required=True)
    args = parser.parse_args()
    try:
        if args.phase == "validate-tag":
            value = {"sourceCommit": validate_tag(args.tag_prefix)}
        elif args.phase == "prepare":
            value = prepare(args.directory, tag_prefix=args.tag_prefix)
        elif args.phase == "verify-summary":
            value = verify_summary(read_json(args.summary), args.expected, args.expected_executions)
        elif args.phase == "local-product-source":
            value = local_product_source_inputs()
        elif args.phase == "verify-local-product":
            value = verify_local_product(read_json(args.summary), read_json(args.tests))
        else:
            value = result(read_json(args.audit), read_json(args.settings), read_json(args.unit),
                           read_json(args.ui), read_json(args.paging), read_json(args.product), read_json(args.product_tests))
            config.write_new_json(args.output, value)
        print(json.dumps(value, indent=2))
        return 0
    except Exception as error:
        print(f"{type(error).__name__}: {error}", file=sys.stderr)
        return 1
