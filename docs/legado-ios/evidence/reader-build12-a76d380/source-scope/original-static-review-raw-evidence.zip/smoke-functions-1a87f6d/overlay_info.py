def overlay_info(path, record_path, source_commit=None):
    if source_commit is not None and (not isinstance(source_commit, str)
                                      or re.fullmatch(r"[0-9a-f]{40}", source_commit) is None):
        raise ValueError("Info source stamp requires a full lowercase source Git SHA")
    path, record_path = config.checked_path(path), config.checked_path(record_path)
    if record_path.exists():
        raise ValueError("Refusing to replace prior Info overlay evidence")
    original = path.read_bytes()
    info = plistlib.loads(original)
    info.update(config.LOCAL_FLAGS)
    info["GatewayBaseURL"] = ""
    info["GIDClientID"] = config.GOOGLE_CLIENT
    if source_commit is not None:
        info["YueduExperienceSourceCommit"] = source_commit
        info["GitCommitSHA"] = source_commit[:7]
    for entry in info.get("CFBundleURLTypes", []):
        entry["CFBundleURLSchemes"] = [config.GOOGLE_REVERSED if item.startswith("com.googleusercontent.apps.") else item
                                       for item in entry.get("CFBundleURLSchemes", [])]
    replacement = plistlib.dumps(info, fmt=plistlib.FMT_XML, sort_keys=False)
    record = {"path": INFO, "originalSHA256": hashlib.sha256(original).hexdigest(),
              "overlaySHA256": hashlib.sha256(replacement).hexdigest(),
              "localFlags": config.LOCAL_FLAGS, "gatewayConfigured": False,
              "upstreamOAuthReplaced": True, "expectedTrackedOverlay": True}
    if source_commit is not None:
        record["sourceCommitStamped"] = source_commit
    config.write_new_json(record_path, record)
    path.write_bytes(replacement)
    return record
