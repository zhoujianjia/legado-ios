def prepare(directory, tag_prefix="reader-smoke-"):
    # Retain the zero-argument default used by the existing private smoke
    # adapters; an additional protocol must explicitly opt into its own tag.
    source = validate_tag() if tag_prefix == "reader-smoke-" else validate_tag(tag_prefix)
    if git("status", "--porcelain", "--untracked-files=no"):
        raise ValueError("Smoke preparation requires a clean tracked source checkout")
    directory = config.checked_path(directory)
    directory.mkdir(parents=True, exist_ok=True)
    audit_path = directory / "overlays.json"
    if audit_path.exists():
        raise ValueError("Refusing to overwrite smoke overlay evidence")
    for path in OVERLAYS:
        if (REPO / path).read_bytes() != git("show", "HEAD:" + path, binary=True):
            raise ValueError("Source bytes differ from HEAD before smoke overlay: " + path)
    synthetic = config.stage(REPO / "GoogleService-Info.plist")
    project = config.overlay_project(REPO / config.PROJECT, directory / "project-overlay.json")
    if tag_prefix == "reader-renewal-":
        info = overlay_info(REPO / INFO, directory / "info-overlay.json", source_commit=source)
    else:
        info = overlay_info(REPO / INFO, directory / "info-overlay.json")
    audit = {"schemaVersion": 1, "sourceCommit": source, "preparedAt": datetime.now(timezone.utc).isoformat(),
             "expectedTrackedChanges": sorted({INFO} | ({config.PROJECT} if project["expectedTrackedOverlay"] else set())),
             "projectOverlay": project, "infoOverlay": info,
             "syntheticConfiguration": synthetic, "paidFeatureOverrides": False,
             "deliveredIPAModified": False, "configuration": "Debug"}
    review_overlays(audit)
    config.write_new_json(audit_path, audit)
    return audit
