def read_json(path):
    return json.loads(path.read_text(encoding="utf-8"))
