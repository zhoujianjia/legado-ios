def require_local_info(info):
    for name, expected in config.LOCAL_FLAGS.items():
        if info.get(name) is not expected:
            raise ValueError("Missing explicit local-mode Info Boolean: " + name)
    if info.get("GatewayBaseURL") != "" or info.get("GIDClientID") != config.GOOGLE_CLIENT:
        raise ValueError("Smoke host must have an empty gateway and synthetic OAuth identity")
