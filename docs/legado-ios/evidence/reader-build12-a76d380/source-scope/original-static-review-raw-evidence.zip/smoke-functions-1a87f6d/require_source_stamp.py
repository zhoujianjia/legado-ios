def require_source_stamp(info, source):
    if (not isinstance(source, str) or re.fullmatch(r"[0-9a-f]{40}", source) is None
            or info.get("YueduExperienceSourceCommit") != source
            or info.get("GitCommitSHA") != source[:7]):
        raise ValueError("Info source stamp must match the full and short preparation source SHA")
