def review_overlays(audit):
    if audit.get("sourceCommit") != source_sha():
        raise ValueError("Smoke source HEAD changed after preparation")
    project = audit["projectOverlay"]
    if type(project.get("expectedTrackedOverlay")) is not bool:
        raise ValueError("Project overlay must declare its actual tracked-change state")
    expected_changes = {INFO} | ({config.PROJECT} if project["expectedTrackedOverlay"] else set())
    if set(git("diff", "--name-only", "HEAD").splitlines()) != expected_changes:
        raise ValueError("Only the declared source Info/project overlays may change tracked inputs")
    if "expectedTrackedChanges" in audit and audit["expectedTrackedChanges"] != sorted(expected_changes):
        raise ValueError("Declared tracked changes differ from the actual project overlay")
    for record in (audit["projectOverlay"], audit["infoOverlay"]):
        if record["path"] not in OVERLAYS or config.digest(REPO / record["path"]) != record["overlaySHA256"]:
            raise ValueError("Working smoke overlay differs from its audit record")
        if hashlib.sha256(git("show", "HEAD:" + record["path"], binary=True)).hexdigest() != record["originalSHA256"]:
            raise ValueError("Original smoke overlay bytes differ from source HEAD")
    config.review_project_overlay(project, git("show", "HEAD:" + config.PROJECT, binary=True),
                                  (REPO / config.PROJECT).read_bytes())
    info = plistlib.loads((REPO / INFO).read_bytes())
    require_local_info(info)
    if "sourceCommitStamped" in audit["infoOverlay"]:
        if audit["infoOverlay"]["sourceCommitStamped"] != audit["sourceCommit"]:
            raise ValueError("Info source stamp differs from its preparation source")
        require_source_stamp(info, audit["sourceCommit"])
    if plistlib.loads((REPO / "GoogleService-Info.plist").read_bytes()) != config.synthetic_config():
        raise ValueError("Smoke Firebase configuration must remain exactly synthetic")
