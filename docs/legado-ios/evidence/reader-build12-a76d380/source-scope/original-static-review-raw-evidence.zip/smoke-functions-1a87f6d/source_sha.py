def source_sha():
    source = git("rev-parse", "HEAD")
    if re.fullmatch(r"[0-9a-f]{40}", source) is None:
        raise ValueError("Expected a full source Git SHA")
    return source
