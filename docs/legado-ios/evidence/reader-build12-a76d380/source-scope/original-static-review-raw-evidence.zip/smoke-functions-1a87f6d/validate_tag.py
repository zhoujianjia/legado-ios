def validate_tag(tag_prefix="reader-smoke-"):
    if tag_prefix not in ("reader-smoke-", "reader-renewal-"):
        raise ValueError("Unsupported isolated Simulator test tag prefix")
    source = source_sha()
    if os.environ.get("GITHUB_SHA") != source or os.environ.get("GITHUB_REF_NAME") != tag_prefix + source[:7]:
        raise ValueError("Expected " + tag_prefix + "<current SHA7> and matching checkout")
    return source
