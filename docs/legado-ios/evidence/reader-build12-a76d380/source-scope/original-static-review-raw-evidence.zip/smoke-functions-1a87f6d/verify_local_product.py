def verify_local_product(summary, tests, repo=None):
    counts = verify_summary(summary, LOCAL_PRODUCT_METHOD_COUNT, LOCAL_PRODUCT_EXECUTION_COUNT)
    sources = local_product_source_inputs(repo)
    return {**counts, **verify_local_product_cases(tests), "sourceMethodInventory": sources}
