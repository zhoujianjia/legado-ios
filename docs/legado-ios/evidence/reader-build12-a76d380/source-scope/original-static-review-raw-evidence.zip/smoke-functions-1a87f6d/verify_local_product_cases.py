def verify_local_product_cases(tree):
    # Parameter nodes use the actual xcresult schema frozen in
    # ios-cache-tests-f73f0ae.json: Test Case -> individual Arguments leaves.
    if not isinstance(tree, dict) or not isinstance(tree.get("testNodes"), list):
        raise ValueError("Local-product case gate requires xcresult testNodes")
    found = {}

    def visit(node):
        if not isinstance(node, dict):
            raise ValueError("Malformed local-product test node")
        children = node.get("children", [])
        if not isinstance(children, list):
            raise ValueError("Malformed local-product child nodes")
        kind = node.get("nodeType")
        if kind == "Test Case":
            identifier = node.get("nodeIdentifier")
            if not isinstance(identifier, str):
                raise ValueError("Local-product test case lacks its source method identifier")
            parts = identifier.split("/")
            if len(parts) == 3 and parts[0] == "yuedu appTests":
                parts = parts[1:]
            identity = "/".join(parts)
            expected = LOCAL_PRODUCT_EXECUTIONS.get(identity)
            if expected is None or identity in found or node.get("result") != "Passed":
                raise ValueError("Unexpected, duplicate, skipped or failed local-product method: " + identifier)
            if expected == 1:
                if children:
                    raise ValueError("Unexpected execution children for nonparameterized method: " + identity)
            else:
                argument_names = []
                for child in children:
                    if (not isinstance(child, dict) or child.get("nodeType") != "Arguments"
                            or child.get("result") != "Passed" or child.get("children", []) != []
                            or not isinstance(child.get("name"), str) or not child["name"]):
                        raise ValueError("Malformed, skipped or failed local-product argument execution: " + identity)
                    argument_names.append(child["name"])
                if len(argument_names) != expected or len(set(argument_names)) != expected:
                    raise ValueError("Missing, duplicate or extra local-product argument executions: " + identity)
            found[identity] = expected
            return
        if kind not in ("Test Plan", "Unit test bundle", "Test Suite"):
            raise ValueError("Unexpected local-product test node type: " + str(kind))
        if node.get("result", "Passed") != "Passed":
            raise ValueError("Skipped or failed local-product test container")
        for child in children:
            visit(child)

    for node in tree["testNodes"]:
        visit(node)
    if found != LOCAL_PRODUCT_EXECUTIONS:
        raise ValueError("Actual local-product source method identities differ from the fixed selection")
    return {"passedCaseIdentifiers": sorted(found), "passedExecutionsByMethod": dict(sorted(found.items()))}
