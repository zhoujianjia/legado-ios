def verify_summary(summary, expected, expected_executions=None):
    if not isinstance(summary, dict):
        raise ValueError("xcresult summary must be an object with explicit test counts")
    fields = {name: summary.get(name) for name in ("totalTestCount", "passedTests", "failedTests", "skippedTests")}
    if any(type(value) is not int for value in fields.values()):
        raise ValueError("xcresult summary lacks explicit integer test counts")
    if fields != {"totalTestCount": expected, "passedTests": expected, "failedTests": 0, "skippedTests": 0}:
        raise ValueError("Smoke test count/failure/skip gate failed: " + json.dumps(fields))
    result = {"expectedTests": expected, **fields}
    if expected_executions is not None:
        # xcresult's top-level count is unique test methods. Parameterized runs
        # are counted separately in the single selected device/configuration.
        devices = summary.get("devicesAndConfigurations")
        if not isinstance(devices, list) or len(devices) != 1 or not isinstance(devices[0], dict):
            raise ValueError("Execution gate requires exactly one device/configuration")
        counts = {name: devices[0].get(name) for name in ("passedTests", "failedTests", "skippedTests", "expectedFailures")}
        if any(type(value) is not int for value in counts.values()) or counts != {
            "passedTests": expected_executions, "failedTests": 0, "skippedTests": 0, "expectedFailures": 0
        } or type(summary.get("expectedFailures")) is not int or summary["expectedFailures"] != 0:
            raise ValueError("Parameterized execution/failure/skip gate failed: " + json.dumps(counts))
        result.update(expectedExecutions=expected_executions, deviceExecutionCounts=counts)
    return result
