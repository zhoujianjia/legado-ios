def main():
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="phase", required=True)
    validation = commands.add_parser("validate-tag")
    validation.add_argument("--tag-prefix", choices=("reader-smoke-", "reader-renewal-"), default="reader-smoke-")
    preparation = commands.add_parser("prepare")
    preparation.add_argument("--directory", type=Path, required=True)
    preparation.add_argument("--tag-prefix", choices=("reader-smoke-", "reader-renewal-"), default="reader-smoke-")
    verify = commands.add_parser("verify-summary")
    verify.add_argument("--summary", type=Path, required=True)
    verify.add_argument("--expected", type=int, required=True)
    verify.add_argument("--expected-executions", type=int)
    summarize = commands.add_parser("result", help="Require configuration=9, product=41, paging=12 and TXT UI=1 summaries")
    for name in ("audit", "settings", "unit", "ui", "paging", "product", "output"):
        summarize.add_argument("--" + name, type=Path, required=True)
    args = parser.parse_args()
    try:
        if args.phase == "validate-tag":
            value = {"sourceCommit": validate_tag(args.tag_prefix)}
        elif args.phase == "prepare":
            value = prepare(args.directory, tag_prefix=args.tag_prefix)
        elif args.phase == "verify-summary":
            value = verify_summary(read_json(args.summary), args.expected, args.expected_executions)
        else:
            value = result(read_json(args.audit), read_json(args.settings), read_json(args.unit),
                           read_json(args.ui), read_json(args.paging), read_json(args.product))
            config.write_new_json(args.output, value)
        print(json.dumps(value, indent=2))
        return 0
    except Exception as error:
        print(f"{type(error).__name__}: {error}", file=sys.stderr)
        return 1
