def result(audit, settings, unit, ui, paging, product):
    review_overlays(audit)
    matches = [item["buildSettings"] for item in settings if item.get("target") == config.MAIN_TARGET]
    if len(matches) != 1:
        raise ValueError("Expected exactly one main reader test host")
    actual = matches[0]
    for name, expected in {"CONFIGURATION": "Debug", "SWIFT_VERSION": "5.0", "PLATFORM_NAME": "iphonesimulator",
                           "PRODUCT_BUNDLE_IDENTIFIER": config.MAIN_BUNDLE}.items():
        if actual.get(name) != expected:
            raise ValueError("Unexpected actual smoke host setting: " + name)
    app = config.checked_path(Path(actual["TARGET_BUILD_DIR"]) / actual["FULL_PRODUCT_NAME"])
    info = config.read_info(app)
    require_local_info(info)
    if plistlib.loads((app / "GoogleService-Info.plist").read_bytes()) != config.synthetic_config():
        raise ValueError("The tested app must include the exact synthetic Firebase configuration")
    if info.get("CFBundleSupportedPlatforms") != ["iPhoneSimulator"] or info.get("CFBundleIdentifier") != config.MAIN_BUNDLE:
        raise ValueError("The tested app must be the isolated local Simulator reader")
    config.no_jvm_payload(app)
    return {"schemaVersion": 1, "sourceCommit": audit["sourceCommit"], "configuration": "Debug",
            "executionPlatform": "ios-simulator", "simulatorDestination": os.environ.get("YUEDU_DEST"),
            "developerDirectory": os.environ.get("DEVELOPER_DIR"), "status": "passed",
            "targetedTests": {"cloudKitAndLocalServicesConfiguration": verify_summary(unit, 9),
                              "localProductFeatures": verify_summary(product, 41),
                              "searchAutoPaging": verify_summary(paging, 12), "TXTReaderUI": verify_summary(ui, 1)},
            "testedApp": str(app), "testedInfoSHA256": config.digest(app / "Info.plist"),
            "sourceOverlays": audit, "readerRoute": "Existing Yuedu/CoreText local TXT reader and source search pagination",
            "covered": ["TXT auto-import through LocalBookImportService", "bookshelf entry", "visible CoreText body",
                        "chapter selection through the real TOC", "shelf progress and selected chapter restored after relaunch",
                        "source HTTP-stub pagination through real HTML parsing and hasMoreRule evaluation",
                        "first-page false stops paging; true, invalid and unknown/cache verdicts preserve bounded paging"],
            "paidFeatureOverrides": False, "jvmIntegratedIntoReading": False,
            "deliveredIPAExecuted": False, "deviceValidationPassed": False,
            "limitations": ["Debug Simulator test, not execution of the delivered Release IPA.",
                            "Auto-import uses an existing DEBUG hook, not the Files picker UI.",
                            "This does not accept network sources, EPUB/PDF, RSS, TTS or full Legado compatibility."]}
