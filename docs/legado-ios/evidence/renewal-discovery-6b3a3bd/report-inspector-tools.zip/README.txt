Use this current path for both historical schema-one reports and dynamic schema-two reports:

python -B .build/renewal-discovery/report-inspector/inspect-device-report.py "<explicit report path>"

To bind build/source declarations to an independently audited delivery manifest:

python -B .build/renewal-discovery/report-inspector/inspect-device-report.py "<explicit report path>" --manifest "<explicit build-manifest.json path>" --manifest-sha256 "<digest recorded by the independent delivery audit>"

Do not derive the trusted digest from the report or treat the manifest's own fields as verification. No build-12 source is hardcoded here. Schema-two builds and commits come from the selected manifest. The two old schema-one build/source pairs remain frozen.

CLI exit zero means that the report schema passed. Check status and provenanceEstablished separately. No manifest, an unavailable/invalid manifest, a missing independent digest, or a digest mismatch produces schema-only-contract-checked with provenanceEstablished=false. A valid selected manifest with different build/source/version declarations is rejected. Missing optional schema-two build/source metadata cannot establish provenance.

provenanceEstablished=true means only that report build/source declarations match the exact manifest bytes identified by the externally supplied digest. This tool does not attest delivery history, device authenticity, a re-signed installed app, local-network permission state, VPN state, computer independence, authentication, signing, replacement installation or automatic renewal.

The input limit is 64 KiB per explicitly selected JSON document. Duplicate keys, non-finite numbers, unknown report fields, integer/boolean confusion, nonzero TCP application payload and service-identity/renewal claims are rejected. The count guard permits the actual overflow observations (service 9 or resolved address 33). A global deadline or cancellation can leave exactly one started TCP attempt without a completed result. Elapsed time is not capped at the configured deadline because scheduler accuracy is not established.

Tests are owned synthetic fixtures only:

python -B .build/renewal-discovery/report-inspector/test-inspect-device-report.py -v

The original inspector and its 23 tests under .build/renewal-delivery are unchanged. schema1-frozen.py is a byte-identical copy with a checked SHA256. The current 25 test methods exercise the combined entry path; they do not execute a device or make a renewal claim.
